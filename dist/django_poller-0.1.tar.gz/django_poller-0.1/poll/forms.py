from django import forms
from .models import Question, Answer


class MultipleChoiceForm(forms.Form):
        pass


class SingleChoiceForm(forms.Form):
        pass


class TextfieldForm(forms.Form):
        pass
